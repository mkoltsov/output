#!/usr/bin/env python3
"""Generate a new full-body pose, then restore the exact source face and hair."""

from __future__ import annotations

import os
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from align_source_head import align_head
from zimage_i2i_common import (
    BACKEND_DIR,
    DISALLOWED_EXPLICIT_TERMS,
    SD_CLI,
    cv2,
    detect_face,
    env_float,
    env_int,
    fail,
)


ROOT = Path(__file__).resolve().parent
MODEL = ROOT / "models" / "realvisxl-v40-fp16.safetensors"
PHOTOMAKER = ROOT / "models" / "photomaker-v1.safetensors"

NEGATIVE = (
    "child, teenager, young-looking, different person, hands touching hair, hand over face, "
    "close-up, headshot, bust portrait, cropped body, cropped legs, cropped ankles, cropped feet, "
    "feet outside frame, multiple people, duplicate body, extra limbs, missing limbs, malformed hands, "
    "extra fingers, fused fingers, distorted anatomy, blur, illustration, watermark, text"
)


@dataclass(frozen=True)
class PhotoMakerProfile:
    name: str
    width: int
    height: int
    prompt_prefix: str


POSE_PROFILE = PhotoMakerProfile(
    "photomaker-pose",
    384,
    768,
    "full-length professional studio fashion photograph of one clearly adult woman img age 30, "
    "front-facing face looking at the camera, hands kept away from her face and hair, complete uncropped "
    "body from the top of her hair through both feet and shoes, natural balanced anatomy, realistic skin, "
    "long highlighted blonde-brown wavy hair matching the reference, neutral grey studio background, "
    "full figure centered with floor visible below both shoes, ",
)

OUTFIT_PROFILE = PhotoMakerProfile(
    "photomaker-outfit",
    384,
    576,
    "waist-up professional studio fashion portrait of one clearly adult woman img age 30, "
    "front-facing face looking at the camera, hands kept away from her face and hair, exact requested outfit "
    "clearly visible from shoulders through waist, long highlighted blonde-brown wavy hair matching the reference, "
    "realistic fabric and natural anatomy, neutral grey studio background, ",
)


def create_identity_crop(source: Path, destination: Path) -> None:
    image = cv2.imread(str(source), cv2.IMREAD_COLOR)
    if image is None:
        fail(f"cannot read input image: {source}")
    face = detect_face(image)
    x, y, width, height = map(float, face[:4])
    image_height, image_width = image.shape[:2]
    side = min(
        image_width,
        image_height,
        max(width * 2.2, height * 1.70),
    )
    center_x = x + width / 2
    center_y = y + height * 0.45
    left = max(0, min(image_width - side, center_x - side / 2))
    top = max(0, min(image_height - side, center_y - side / 2))
    crop = image[round(top):round(top + side), round(left):round(left + side)]
    crop = cv2.resize(crop, (512, 512), interpolation=cv2.INTER_LANCZOS4)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if not cv2.imwrite(str(destination), crop):
        fail(f"could not write identity crop: {destination}")


def run(profile: PhotoMakerProfile) -> None:
    if len(sys.argv) != 4:
        fail(f'usage: {Path(sys.argv[0]).name} "IMAGE" "PROMPT" "OUTPUT_FOLDER"')
    source = Path(sys.argv[1]).expanduser().resolve()
    prompt = sys.argv[2].strip()
    output_dir = Path(sys.argv[3]).expanduser().resolve()
    if not source.is_file():
        fail(f"input image does not exist: {source}")
    if not prompt:
        fail("prompt cannot be empty")
    if DISALLOWED_EXPLICIT_TERMS.search(prompt):
        fail("explicit nudification of an identifiable person is not supported")
    for path, minimum in ((SD_CLI, 1_000_000), (MODEL, 6_000_000_000), (PHOTOMAKER, 800_000_000)):
        if not path.is_file() or path.stat().st_size < minimum:
            fail(f"required file is missing or incomplete: {path}")

    output_dir.mkdir(parents=True, exist_ok=True)
    width = env_int("EDIT_WIDTH", profile.width, 320, 640)
    height = env_int("EDIT_HEIGHT", profile.height, 512, 1024)
    steps = env_int("EDIT_STEPS", 18, 12, 30)
    seed = env_int("EDIT_SEED", 62001, 0, 2_147_483_647)
    cfg = env_float("EDIT_CFG", 4.5, 2.0, 8.0)
    style_strength = env_float("EDIT_ID_STRENGTH", 12.0, 5.0, 40.0)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    output = output_dir / f"{source.stem}-{profile.name}-{stamp}-seed{seed}.png"

    with tempfile.TemporaryDirectory(prefix="photomaker-pose-") as temp_dir:
        temp = Path(temp_dir)
        identity_dir = temp / "identity"
        create_identity_crop(source, identity_dir / "source.png")
        generated = temp / "generated.png"
        positive = profile.prompt_prefix + prompt
        command = [
            str(SD_CLI),
            "--model", str(MODEL),
            "--photo-maker", str(PHOTOMAKER),
            "--pm-id-images-dir", str(identity_dir),
            "--pm-style-strength", str(style_strength),
            "--prompt", positive,
            "--negative-prompt", NEGATIVE,
            "--output", str(generated),
            "--width", str(width),
            "--height", str(height),
            "--steps", str(steps),
            "--cfg-scale", str(cfg),
            "--sampling-method", "euler",
            "--scheduler", "discrete",
            "--seed", str(seed),
            "--backend", "diffusion=vulkan0,te=cpu,vae=cpu",
            "--params-backend", "diffusion=disk,te=cpu,vae=cpu",
            "--max-vram", "vulkan0=2.0",
            "--mmap",
            "--rng", "cpu",
            "--vae-tiling",
            "--fa",
        ]
        environment = os.environ.copy()
        old = environment.get("LD_LIBRARY_PATH", "")
        environment["LD_LIBRARY_PATH"] = (
            str(BACKEND_DIR) if not old else f"{BACKEND_DIR}:{old}"
        )
        print(
            f"Mode: {profile.name} + exact head restoration\nInput: {source}\nOutput: {output}\n"
            f"Size: {width}x{height}\nSteps: {steps}\nSeed: {seed}\nIdentity strength: {style_strength}",
            flush=True,
        )
        try:
            subprocess.run(command, env=environment, check=True)
        except subprocess.CalledProcessError as exc:
            fail(f"PhotoMaker inference failed with exit code {exc.returncode}")
        if not generated.is_file() or generated.stat().st_size == 0:
            fail("PhotoMaker did not produce an image")
        align_head(source, generated, output)

    if not output.is_file() or output.stat().st_size == 0:
        fail("head-restored pose output was not created")
    print(f"Saved: {output}")


if __name__ == "__main__":
    run(POSE_PROFILE)
