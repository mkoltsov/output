#!/usr/bin/env python3
"""Transfer the source face and hairstyle to a generated pose using landmarks."""

from __future__ import annotations

import argparse
import tempfile
from pathlib import Path

from zimage_i2i_common import (
    OUTFIT_PROFILE,
    cv2,
    detect_face,
    fail,
    np,
    prepare_input_and_mask,
)


def align_head(
    source_path: Path,
    target_path: Path,
    output_path: Path,
    feather: float = 0.025,
    seamless: bool = False,
) -> None:
    source = cv2.imread(str(source_path), cv2.IMREAD_COLOR)
    target = cv2.imread(str(target_path), cv2.IMREAD_COLOR)
    if source is None or target is None:
        fail("could not read source or target")

    source_face = detect_face(source)
    target_face = detect_face(target)
    source_points = source_face[4:14].reshape(5, 2).astype(np.float32)
    target_points = target_face[4:14].reshape(5, 2).astype(np.float32)
    matrix, _ = cv2.estimateAffinePartial2D(source_points, target_points, method=cv2.LMEDS)
    if matrix is None:
        fail("could not align the source and target faces")

    with tempfile.TemporaryDirectory(prefix="head-mask-") as temp_dir:
        prepared_path = Path(temp_dir) / "source.png"
        mask_path = Path(temp_dir) / "protection.png"
        prepare_input_and_mask(
            source_path,
            prepared_path,
            mask_path,
            source.shape[1],
            source.shape[0],
            OUTFIT_PROFILE,
        )
        source_mask = cv2.imread(str(mask_path), cv2.IMREAD_GRAYSCALE)
    if source_mask is None:
        fail("could not create source head mask")

    target_height, target_width = target.shape[:2]
    warped_source = cv2.warpAffine(
        source,
        matrix,
        (target_width, target_height),
        flags=cv2.INTER_LANCZOS4,
        borderMode=cv2.BORDER_REFLECT_101,
    )
    warped_mask = cv2.warpAffine(
        source_mask,
        matrix,
        (target_width, target_height),
        flags=cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=0,
    )

    target_face_width = max(1.0, float(target_face[2]))
    sigma = max(1.5, target_face_width * feather)
    warped_mask = cv2.GaussianBlur(warped_mask, (0, 0), sigma)
    if seamless:
        clone_mask = np.where(warped_mask > 24, 255, 0).astype(np.uint8)
        points = cv2.findNonZero(clone_mask)
        if points is None:
            fail("warped head mask is empty")
        bx, by, bw, bh = cv2.boundingRect(points)
        clone_center = (bx + bw // 2, by + bh // 2)
        result = cv2.seamlessClone(
            warped_source, target, clone_mask, clone_center, cv2.MIXED_CLONE
        )
    else:
        alpha = np.clip(warped_mask.astype(np.float32) / 255.0, 0.0, 1.0)[..., None]
        result = np.clip(
            warped_source.astype(np.float32) * alpha
            + target.astype(np.float32) * (1.0 - alpha),
            0,
            255,
        ).astype(np.uint8)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    if not cv2.imwrite(str(output_path), result):
        fail(f"could not write {output_path}")
    print(f"source_face={source_face[:4].round(2).tolist()}")
    print(f"target_face={target_face[:4].round(2).tolist()}")
    print(f"saved={output_path}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("target")
    parser.add_argument("output")
    parser.add_argument("--feather", type=float, default=0.025)
    parser.add_argument("--seamless", action="store_true")
    args = parser.parse_args()
    align_head(
        Path(args.source).expanduser().resolve(),
        Path(args.target).expanduser().resolve(),
        Path(args.output).expanduser().resolve(),
        args.feather,
        args.seamless,
    )


if __name__ == "__main__":
    main()
