#!/usr/bin/env python3
"""Shared identity-mask and runtime helpers for the local PhotoMaker editors."""

from __future__ import annotations

import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path


VENV_PYTHON = Path(__file__).resolve().parent / ".venv-face" / "bin" / "python"
try:
    import cv2
    import numpy as np
except ModuleNotFoundError:
    # Keep the documented `python3 script.py ...` interface even though OpenCV
    # is isolated in the project's small face-processing virtual environment.
    if VENV_PYTHON.is_file() and Path(sys.executable).resolve() != VENV_PYTHON.resolve():
        os.execv(str(VENV_PYTHON), [str(VENV_PYTHON), *sys.argv])
    raise


ROOT = Path(__file__).resolve().parent
BACKEND_DIR = ROOT / "backend"
SD_CLI = BACKEND_DIR / "sd-cli"
FACE_DETECTOR = ROOT / "models" / "face_detection_yunet_2023mar.onnx"

# This editor may be used with synthetic adults, but it must not turn an
# identifiable person's photograph into explicit sexual content.
DISALLOWED_EXPLICIT_TERMS = re.compile(
    r"\b(?:nude|nudity|naked|undress(?:ed|ing)?|topless|bottomless|porn(?:ographic)?|"
    r"explicit|genitals?|vulva|vagina|penis|nipples?|areolae?|sex(?:ual)?|intercourse)\b",
    re.IGNORECASE,
)

@dataclass(frozen=True)
class EditProfile:
    mask_center_y: float


OUTFIT_PROFILE = EditProfile(
    mask_center_y=0.54,
)


def fail(message: str) -> "NoReturn":
    print(f"error: {message}", file=sys.stderr)
    raise SystemExit(2)


def env_float(name: str, default: float, minimum: float, maximum: float) -> float:
    raw = os.environ.get(name)
    if raw is None:
        return default
    try:
        value = float(raw)
    except ValueError:
        fail(f"{name} must be a number")
    if not minimum <= value <= maximum:
        fail(f"{name} must be between {minimum} and {maximum}")
    return value


def env_int(name: str, default: int, minimum: int, maximum: int) -> int:
    raw = os.environ.get(name)
    if raw is None:
        return default
    try:
        value = int(raw)
    except ValueError:
        fail(f"{name} must be an integer")
    if not minimum <= value <= maximum:
        fail(f"{name} must be between {minimum} and {maximum}")
    return value


def detect_face(image: np.ndarray) -> np.ndarray:
    height, width = image.shape[:2]
    detector = cv2.FaceDetectorYN.create(
        str(FACE_DETECTOR), "", (width, height), 0.45, 0.3, 5000
    )
    _, faces = detector.detect(image)
    if faces is None or len(faces) == 0:
        fail("no face was detected; refusing to edit without identity protection")
    return max(faces, key=lambda face: float(face[2] * face[3]))


def prepare_input_and_mask(
    source_path: Path,
    prepared_path: Path,
    mask_path: Path,
    width: int,
    height: int,
    profile: EditProfile,
) -> tuple[list[float], float]:
    source = cv2.imread(str(source_path), cv2.IMREAD_COLOR)
    if source is None:
        fail(f"cannot read input image: {source_path}")
    prepared = cv2.resize(source, (width, height), interpolation=cv2.INTER_LANCZOS4)
    face = detect_face(prepared)
    x, y, face_width, face_height = map(float, face[:4])

    # Build a compact white protection region from the detected
    # face plus connected, chromatic foreground pixels around it. On the given
    # studio portrait this follows the brown/blonde hair while excluding the
    # neutral-grey backdrop and white blazer much more accurately than an oval.
    center = (
        round(x + face_width / 2),
        round(y + face_height * profile.mask_center_y),
    )
    face_core = np.zeros((height, width), dtype=np.uint8)
    cv2.ellipse(
        face_core,
        center,
        (max(1, round(face_width * 0.61)), max(1, round(face_height * 0.48))),
        0,
        0,
        360,
        255,
        -1,
        cv2.LINE_AA,
    )

    hsv = cv2.cvtColor(prepared, cv2.COLOR_BGR2HSV)
    saturation = hsv[:, :, 1]
    value = hsv[:, :, 2]
    broad_roi = np.zeros((height, width), dtype=np.uint8)
    roi_left = max(0, round(x - face_width * 0.78))
    roi_right = min(width, round(x + face_width * 1.78))
    roi_top = max(0, round(y - face_height * 0.48))
    roi_bottom = min(height, round(y + face_height * 1.62))
    broad_roi[roi_top:roi_bottom, roi_left:roi_right] = 255

    chromatic_foreground = (
        (saturation >= 40) & (value >= 28) & (value <= 248) & (broad_roi > 0)
    ).astype(np.uint8) * 255
    candidate = cv2.bitwise_or(chromatic_foreground, face_core)
    close_radius = max(3, round(face_width * 0.015))
    kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE, (close_radius * 2 + 1, close_radius * 2 + 1)
    )
    candidate = cv2.morphologyEx(candidate, cv2.MORPH_CLOSE, kernel)

    count, labels = cv2.connectedComponents((candidate > 0).astype(np.uint8))
    core_labels = np.unique(labels[face_core > 0])
    protection = np.isin(labels, core_labels[core_labels != 0]).astype(np.uint8) * 255
    protection = cv2.bitwise_or(protection, face_core)

    fill_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))
    protection = cv2.morphologyEx(protection, cv2.MORPH_CLOSE, fill_kernel)

    dilation = max(3, round(face_width * 0.025))
    dilation_kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE, (dilation * 2 + 1, dilation * 2 + 1)
    )
    protection = cv2.dilate(protection, dilation_kernel)

    # Remove bright neutral source-garment pixels beneath the chin while
    # retaining the more chromatic hair on both sides. This prevents a white
    # blazer collar from being pasted onto a newly generated dark outfit.
    rows = np.arange(height, dtype=np.int32)[:, None]
    columns = np.arange(width, dtype=np.int32)[None, :]
    central_column = (
        (columns >= round(x - face_width * 0.05))
        & (columns <= round(x + face_width * 1.05))
    )
    source_garment = (
        (rows >= round(y + face_height * 0.94))
        & central_column
        & (saturation < 34)
        & (value > 155)
    )
    protection[source_garment] = 0
    feather_sigma = max(2.0, face_width * 0.018)
    protection = cv2.GaussianBlur(protection, (0, 0), feather_sigma)
    mask = protection

    if not cv2.imwrite(str(prepared_path), prepared):
        fail(f"could not write prepared input: {prepared_path}")
    if not cv2.imwrite(str(mask_path), mask):
        fail(f"could not write edit mask: {mask_path}")
    protected_fraction = float(np.mean(mask > 223))
    return [x, y, face_width, face_height], protected_fraction
