#!/usr/bin/env python3
"""Generate a new outfit portrait, then restore the source face and hairstyle."""

from edit_photomaker_pose import OUTFIT_PROFILE, run


if __name__ == "__main__":
    run(OUTFIT_PROFILE)

