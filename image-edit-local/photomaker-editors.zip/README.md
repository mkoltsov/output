# Local image editors

Each script accepts exactly three positional arguments:

1. Path to the source image
2. Edit prompt
3. Output folder

Examples:

```bash
python3 edit_realistic_vision.py "/path/source.png" "wearing a red evening dress" "/path/outputs"
python3 edit_stable_yogi.py "/path/source.png" "wearing a red evening dress" "/path/outputs"
python3 edit_cyberrealistic.py "/path/source.png" "wearing a red evening dress" "/path/outputs"
```

The scripts preserve the input aspect ratio, round dimensions to multiples of 64,
and limit the longest side to 768 pixels by default. Output names are unique and
never overwrite an earlier result.

Optional environment variables do not change the three-argument interface:

- `EDIT_STRENGTH`: edit strength from `0.05` to `1.0`; default `0.65`
- `EDIT_SEED`: `-1` for random or a non-negative integer; default `-1`
- `EDIT_MAX_SIDE`: longest output side from 256 to 1024; default `768`

Example with a gentler deterministic edit:

```bash
EDIT_STRENGTH=0.45 EDIT_SEED=42 python3 edit_realistic_vision.py input.png "add a blue jacket" outputs
```

The backend is `stable-diffusion.cpp` using the laptop's `Vulkan0` Radeon device.
These SD 1.5 models perform generative image-to-image transformation, not Qwen-style
precise semantic editing. Lower `EDIT_STRENGTH` preserves more of the source image.

## PornMaster Z-Image Turbo

`generate_pornmaster_z.py` performs local text-to-image generation with a local
Q4_K conversion of the exact PornMaster Z-Image Turbo V3.5 FP8 checkpoint and
the exact PornMaster NSFW ZIT_V1 LoRA. The original FP8 file is retained for
provenance; Q4_K avoids the backend expanding it to 11.74 GB of FP16 tensors.
It accepts three positional arguments:

```bash
python3 generate_pornmaster_z.py "PROMPT" OUTPUT_FOLDER SEED
```

The defaults are 512 x 768 pixels and eight Euler steps. Override them with
`ZIMAGE_WIDTH`, `ZIMAGE_HEIGHT`, `ZIMAGE_STEPS`, and `ZIMAGE_LORA_WEIGHT`.
This is text-to-image generation; neither the checkpoint nor the LoRA provides
single-photo identity preservation.

The verified ThinkPad configuration uses disk-backed diffusion parameters,
CPU text encoding and VAE decoding, Vulkan diffusion with a 2 GiB graph-cut
budget, VAE tiling, 512 x 768 pixels, and eight Euler steps.

## Installed models

- `edit_realistic_vision.py`: Realistic Vision V6.0 B1 FP16
  - https://huggingface.co/SG161222/Realistic_Vision_V6.0_B1_noVAE
- `edit_stable_yogi.py`: Stable Yogi SD1.5 V9 LCM FP16
  - https://huggingface.co/Stableyogi/Realism-Checkpoints
- `edit_cyberrealistic.py`: CyberRealistic V9 FP16
  - https://huggingface.co/cyberdelia/CyberRealistic
- Shared VAE: Stability AI `vae-ft-mse-840000-ema-pruned`
  - https://huggingface.co/stabilityai/sd-vae-ft-mse-original

The Vulkan backend is `stable-diffusion.cpp` commit `b11c95a`, release
`master-749-b11c95a`.

## Verified performance on this ThinkPad

On 4 July 2026 all three scripts completed real 256 x 256 image-to-image edits
using `Vulkan0 (AMD Radeon Graphics, RADV RENOIR)`. The measured end-to-end times
were approximately 21 seconds for Realistic Vision, 11 seconds for Stable Yogi
LCM, and 20 seconds for CyberRealistic. Stable Yogi also completed a default
512 x 768 edit in approximately 56 seconds.

These are generative edits. They do not guarantee facial identity preservation;
use a lower `EDIT_STRENGTH` when keeping the source composition matters most.

Use these models only for lawful content involving consenting adults.
## Identity-preserving outfit and pose editors

The PhotoMaker editors generate the requested clothing/pose with local
RealVisXL and then align and restore the source face and hairstyle. They accept
exactly three arguments:

```bash
python3 edit_photomaker_outfit.py "/path/input.jpg" "wearing a fitted black evening dress" "/path/output"
python3 edit_photomaker_pose.py "/path/input.jpg" "standing with one hand on her hip, wearing a fitted black dress" "/path/output"
```

The outfit editor defaults to a 512 x 768 waist-up portrait. The pose editor
defaults to a 384 x 768 full-body frame. Both use low-memory placement verified
on this ThinkPad: diffusion on segmented Vulkan, text encoding and VAE on the
CPU, and memory-mapped model weights.

```bash
EDIT_SEED=123 EDIT_STEPS=14 EDIT_CFG=5.5 python3 edit_photomaker_outfit.py INPUT PROMPT OUTPUT_DIR
```

Supported overrides are `EDIT_SEED`, `EDIT_STEPS`, `EDIT_CFG`, `EDIT_WIDTH`,
`EDIT_HEIGHT`, and `EDIT_ID_STRENGTH`.

These scripts intentionally reject prompts asking to turn a photograph of an
identifiable person into explicit sexual content. They are intended for normal
clothing changes and body-pose adjustments.
